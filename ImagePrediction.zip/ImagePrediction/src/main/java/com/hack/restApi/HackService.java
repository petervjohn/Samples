package com.hack.restApi;

import java.io.InputStream;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.ws.RequestWrapper;

import com.hack.service.BusinessLogic;

@Path("/predict")
public class HackService {

	@GET
	@Path("/{param}")
	public Response getMsg(@PathParam("param") final String msg) {

		final String output = "Hai user : " + msg;

		return Response.status(200).entity(output).build();

	}

	@POST
	@Path("/detect/{param}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response callPythonService(@PathParam("param") String msg) throws Exception {
		final String json = "\"biriyani\": \"99\"";
		System.out.println("Data Received: " + msg);
		
		// return HTTP response 200 in case of success
		final BusinessLogic bl = new BusinessLogic();
		return Response.status(200).entity(json.toString()).build();
		//return Response.status(200).entity(bl.detectService()).build();
	}

}