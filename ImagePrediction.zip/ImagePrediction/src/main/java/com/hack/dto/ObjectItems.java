package com.hack.dto;

public class ObjectItems {
	int id;
	String objectName;
	int calloryValue;

	public int getId() {
		return id;
	}

	public void setId(final int id) {
		this.id = id;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(final String objectName) {
		this.objectName = objectName;
	}

	public int getCalloryValue() {
		return calloryValue;
	}

	public void setCalloryValue(final int calloryValue) {
		this.calloryValue = calloryValue;
	}
}
