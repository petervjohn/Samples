package com.hack.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.python.core.PyObject;
import org.python.util.PythonInterpreter;

import com.hack.dto.ObjectItems;

public class BusinessLogic {

	public String detectService() throws Exception {
		final String response = callPython();
		final JSONObject jsonObject = new JSONObject(response);
		final String detectedItem = jsonObject.getString("objectName");
		System.out.println(detectedItem);
		if (jsonObject.getInt("probability") > 70) {
			final List<ObjectItems> items = getObjects();
			if (items != null && !items.isEmpty()) {
				for (final ObjectItems ob : items) {
					if (detectedItem.equalsIgnoreCase(ob.getObjectName())) {
						final StringBuilder sb = new StringBuilder();
						return sb.append("{\"").append(ob.getObjectName()).append("\":").append("\"")
								.append(ob.getCalloryValue()).append("\"}").toString();
					}

				}
			}
		}
		else {
			return "{\"Detect None\"}";
		}
		return null;

	}

	public String callPython() throws Exception {
		System.out.println("hree");
		@SuppressWarnings("resource")
		final PythonInterpreter interpreter = new PythonInterpreter();
		System.out.println("here 2");
		final String test = "test";
		interpreter.execfile("/Users/peter.john/Desktop/detect.py");
		final PyObject str = interpreter.eval("detect().abc('" + test + "')");
		// final PyObject func = interpreter.get("readimage");
		// func.__call__(new PyByteArray(imageBytes));
		return str.toString();
	}

	public List<ObjectItems> getObjects() throws SQLException {
		final List<ObjectItems> items = new ArrayList<ObjectItems>();
		final Connection con = connectDB();
		if (con != null) {
			final Statement stmt = con.createStatement();
			final ResultSet rs = stmt.executeQuery("select * from callory");
			while (rs.next()) {
				System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
				final ObjectItems item = new ObjectItems();
				item.setId(rs.getInt(1));
				item.setObjectName(rs.getString(2));
				item.setCalloryValue(rs.getInt(3));
				items.add(item);
			}
			con.close();
			return items;
		}
		return null;

	}

	public Connection connectDB() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			final Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Hackthon", "root", "");
			return con;
		}
		catch (final Exception e) {
			System.out.println(e);
		}
		return null;
	}

}
